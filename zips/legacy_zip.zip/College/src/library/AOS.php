<script>
    AOS.init({
      duration: 1000, // Animation duration (in milliseconds)
      easing: 'ease-in-out', // Easing type
      once: true, // Only animate elements once
    });
  </script>